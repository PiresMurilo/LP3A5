package jogoLP3;

public class Player {
	
	private String name;
	private String hand;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getHand() {
		return hand;
	}
	
	public void setHand(String hand) {
		this.hand = hand;
	}
	
}
